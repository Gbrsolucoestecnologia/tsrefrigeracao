const videos = [
  { src: 'videos/campo-1.mp4', poster: 'videos/campo-1.jpg', label: 'Equipe em serviço' },
  { src: 'videos/campo-2.mp4', poster: 'videos/campo-2.jpg', label: 'Manutenção em ação' },
]

export function VideoShowcase() {
  const base = import.meta.env.BASE_URL
  return (
    <section id="em-acao" className="section-space overflow-hidden bg-[#061a3d]">
      <div className="container-shell">
        <div className="mx-auto mb-11 max-w-2xl text-center">
          <span className="eyebrow border-white/15 bg-white/10 text-cyan-200">Em ação</span>
          <h2 className="mt-5 text-3xl font-extrabold tracking-[-0.035em] text-white sm:text-4xl">A TS Refrigeração em movimento</h2>
          <p className="mt-4 text-base leading-7 text-blue-100/80">Veja um pouco da nossa rotina de trabalho em campo.</p>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {videos.map((video) => (
            <div key={video.src} className="video-card">
              <video
                src={`${base}${video.src}`}
                poster={`${base}${video.poster}`}
                autoPlay muted loop playsInline preload="metadata"
                aria-label={video.label}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
