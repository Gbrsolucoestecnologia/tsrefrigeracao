import { useEffect, useRef, useState } from 'react'
import { Music, VolumeX } from 'lucide-react'

const STORAGE_KEY = 'tsr-music-pref-v1'
// Coloque o arquivo da trilha em public/audio/trilha.mp3
const TRACK = 'audio/trilha.mp3'

export function MusicToggle() {
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const [playing, setPlaying] = useState(false)
  const [available, setAvailable] = useState(true)

  useEffect(() => {
    const audio = new Audio(`${import.meta.env.BASE_URL}${TRACK}`)
    audio.loop = true
    audio.volume = 0.35
    audio.addEventListener('error', () => setAvailable(false))
    audioRef.current = audio
    return () => { audio.pause() }
  }, [])

  const toggle = () => {
    const audio = audioRef.current
    if (!audio) return
    if (playing) {
      audio.pause()
      setPlaying(false)
      try { localStorage.setItem(STORAGE_KEY, 'off') } catch { /* ignore */ }
    } else {
      audio.play().then(() => {
        setPlaying(true)
        try { localStorage.setItem(STORAGE_KEY, 'on') } catch { /* ignore */ }
      }).catch(() => setAvailable(false))
    }
  }

  if (!available) return null

  return (
    <button
      type="button"
      onClick={toggle}
      className="music-toggle"
      aria-pressed={playing}
      aria-label={playing ? 'Desativar trilha sonora' : 'Ativar trilha sonora'}
      title={playing ? 'Desativar som' : 'Ativar som'}
    >
      {playing ? <Music className="size-5" /> : <VolumeX className="size-5" />}
    </button>
  )
}
