import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Snowflake, GlassWater } from 'lucide-react'

const items = [
  { icon: Snowflake, text: 'Climatização' },
  { icon: GlassWater, text: 'Higienização de bebedouros' },
  { icon: Snowflake, text: 'Manutenção e instalação' },
]

export function RotatingTagline() {
  const [i, setI] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % items.length), 2600)
    return () => clearInterval(t)
  }, [])
  const Icon = items[i].icon
  return (
    <span className="eyebrow">
      <span className="rotating-tagline">
        <AnimatePresence mode="wait">
          <motion.span
            key={i}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.4 }}
            className="flex items-center gap-2"
          >
            <Icon className="size-4" /> {items[i].text}
          </motion.span>
        </AnimatePresence>
      </span>
    </span>
  )
}
