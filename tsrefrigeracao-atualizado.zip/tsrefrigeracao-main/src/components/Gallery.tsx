import { useState } from 'react'
import { X } from 'lucide-react'
import { galleryImages } from '../data/gallery'
import { SectionHeading } from './SectionHeading'

export function Gallery() {
  const [active, setActive] = useState<number | null>(null)
  const base = import.meta.env.BASE_URL

  return (
    <section id="galeria" className="section-space bg-[#f4f9fd]">
      <div className="container-shell">
        <SectionHeading
          eyebrow="Nossos trabalhos"
          title="Veja o nosso serviço de perto"
          description="Instalações, limpezas com antes e depois, manutenção industrial e higienização de bebedouros e gelágua executados pela nossa equipe."
        />
        <div className="gallery-masonry">
          {galleryImages.map((src, index) => (
            <button
              key={src}
              type="button"
              className="gallery-item"
              onClick={() => setActive(index)}
              aria-label={`Ampliar imagem ${index + 1} do nosso trabalho`}
            >
              <img src={`${base}${src}`} alt={`Trabalho da TS Refrigeração ${index + 1}`} loading="lazy" decoding="async" />
            </button>
          ))}
        </div>
      </div>

      {active !== null && (
        <div className="gallery-lightbox" role="dialog" aria-modal="true" onClick={() => setActive(null)}>
          <button type="button" className="gallery-close" aria-label="Fechar" onClick={() => setActive(null)}><X /></button>
          <img src={`${base}${galleryImages[active]}`} alt={`Trabalho da TS Refrigeração ${active + 1}`} onClick={(e) => e.stopPropagation()} />
        </div>
      )}
    </section>
  )
}
